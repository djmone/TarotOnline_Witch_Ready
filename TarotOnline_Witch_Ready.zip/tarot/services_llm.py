
import requests, json
from django.conf import settings
from core.models import GlobalSettings

def _safe_ollama_chat(payload, base):
    try:
        r = requests.post(f"{base}/api/chat", json=payload, timeout=180)
        r.raise_for_status()
        data = r.json()
        if isinstance(data, dict) and 'message' in data:
            return data['message'].get('content','')
        if isinstance(data, list):
            return ''.join(ch.get('message',{}).get('content','') for ch in data)
    except Exception as e:
        return f"(demo offline) {payload['messages'][-1]['content'][:300]} ..."
    return ""

def build_full_prompt(session, lang='ru'):
    preset = session.preset
    cards = session.cards_json
    sys_ru = ("Ты — опытный таролог. Дай структурированную интерпретацию расклада: "
              "1) краткое резюме; 2) по позициям; 3) рекомендации; 4) предупреждения. "
              "Не давай мед/фин советов. Пиши уважительно.")
    sys_en = ("You are an experienced tarot reader. Provide a structured reading: "
              "1) summary; 2) per-position; 3) recommendations; 4) warnings. "
              "No medical/financial advice.")
    system = sys_ru if lang=='ru' else sys_en
    card_lines = []
    for it in cards:
        card_lines.append(f"{it['code']}{' (reversed)' if it['reversed'] else ''}")
    person = session.p1_name
    if session.p1_dob: person += f" ({session.p1_dob})"
    if preset.mode == 'couple':
        p2 = session.p2_name
        if session.p2_dob: p2 += f" ({session.p2_dob})"
        person += f" × {p2}"
    user_msg = (
      f"Preset: {preset.slug}\n"
      f"Person(s): {person}\n"
      f"Extra: {session.extra_questions}\n"
      f"Cards: {', '.join(card_lines)}\n"
      f"Positions schema: {json.dumps(preset.positions_json, ensure_ascii=False)}\n"
      f"Language: {lang}"
    )
    return system, user_msg

def build_step_prompt(session, index, lang='ru', last=False):
    preset = session.preset
    it = session.cards_json[index]
    sys_ru = (
        "Ты — таролог. Дай короткую интерпретацию КОНКРЕТНО для этой карты в своей позиции. "
        "Структура: 1) смысл карты применительно к вопросу; 2) что обратить внимание. "
        "Без мед/фин советов. Кратко, 2–4 предложения."
    )
    sys_en = (
        "You are a tarot reader. Provide a short interpretation ONLY for this single card and its position. "
        "Structure: 1) meaning for the question; 2) what to pay attention to. "
        "No medical/financial advice. Keep it short (2–4 sentences)."
    )
    system = sys_ru if lang == 'ru' else sys_en
    pos = preset.positions_json[index] if index < len(preset.positions_json) else {'title': f'Card {index+1}'}
    person = session.p1_name
    if session.p1_dob: person += f" ({session.p1_dob})"
    if preset.mode == 'couple':
        p2 = session.p2_name
        if session.p2_dob: p2 += f" ({session.p2_dob})"
        person += f" × {p2}"
    tail = ""
    if last:
        tail = (
            "\n\nВажно: закончи одной короткой фразой с интригой или мрачным предчувствием, "
            "без прямых угроз и категоричности (пример: «Но тень ещё не сказала последнего слова…»)."
            if lang == 'ru' else
            "\n\nImportant: end with a short ominous/suspenseful one-liner without direct threats "
            "(e.g., 'But the shadow has not spoken its last word yet...')."
        )
    user_msg = (
      f"Preset: {preset.slug}; Person(s): {person}; Extra: {session.extra_questions}\n"
      f"Position: {pos}\n"
      f"Card: {it['code']}{' (reversed)' if it['reversed'] else ''}{tail}"
    )
    return system, user_msg

def ask_full(session, lang='ru'):
    gs = GlobalSettings.load()
    base = gs.ollama_base_url
    model = gs.llm_model
    temperature = gs.llm_temperature
    max_tokens = gs.llm_max_tokens
    system, user_msg = build_full_prompt(session, lang=lang)
    payload = {"model": model, "messages":[{"role":"system","content":system},{"role":"user","content":user_msg}], "options":{"temperature":temperature,"num_ctx":max_tokens}}
    content = _safe_ollama_chat(payload, base)
    return model, temperature, max_tokens, content

def ask_step(session, index, lang='ru'):
    gs = GlobalSettings.load()
    base = gs.ollama_base_url
    model = gs.llm_model
    temperature = gs.llm_temperature
    max_tokens = gs.llm_max_tokens
    last = (index == len(session.cards_json) - 1)
    system, user_msg = build_step_prompt(session, index, lang=lang, last=last)
    payload = {"model": model, "messages":[{"role":"system","content":system},{"role":"user","content":user_msg}], "options":{"temperature":temperature,"num_ctx":max_tokens}}
    content = _safe_ollama_chat(payload, base)
    return model, temperature, max_tokens, content
