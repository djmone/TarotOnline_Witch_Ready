from django.apps import AppConfig
class TarotConfig(AppConfig): name='tarot'
