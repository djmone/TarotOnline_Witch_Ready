// tarot/static/tarot/js/shuffle3d.js
// Топ-даун (вид сверху), авто-подгонка раскладки под окно, hover-поднятие,
// динамическое создание карт из ответа бэка, анти-мыло.

(() => {
  const mount = document.getElementById('three-stage');
  if (!mount || typeof THREE === 'undefined') {
    console.warn('[tarot] stage or THREE not found');
    return;
  }

  const backUrl  = mount.dataset.backUrl || '/static/tarot/img/back.jpg';
  const dealUrl  = mount.dataset.dealUrl;
  const stageW   = mount.clientWidth;
  const stageH   = mount.clientHeight;

  // ----- СЦЕНА -----
  const scene = new THREE.Scene();

  // ОРТО камера (без перспективы), вид строго сверху
  const frustumSize = 160;                 // логическая высота сцены
  let aspect = stageW / stageH;
  const camera = new THREE.OrthographicCamera(
    -frustumSize * aspect / 2,            // left
     frustumSize * aspect / 2,            // right
     frustumSize / 2,                      // top
    -frustumSize / 2,                      // bottom
     0.1, 1000
  );
  camera.position.set(0, 200, 0);          // камера над столом
  camera.up.set(0, 0, -1);                 // ось "вверх" — к пользователю
  camera.lookAt(0, 0, 0);

  // РЕНДЕР
  const renderer = new THREE.WebGLRenderer({ antialias: true, alpha: true });
  renderer.setPixelRatio(window.devicePixelRatio || 1);
  renderer.setSize(stageW, stageH);
  renderer.outputColorSpace = THREE.SRGBColorSpace;
  mount.appendChild(renderer.domElement);

  // Свет
  scene.add(new THREE.AmbientLight(0xffffff, 0.95));

  // Улучшение качества текстур (анти-мыло)
  function tuneTexture(tex) {
    tex.colorSpace = THREE.SRGBColorSpace;
    tex.anisotropy = renderer.capabilities.getMaxAnisotropy?.() || 8;
    tex.generateMipmaps = true;
    tex.minFilter = THREE.LinearMipmapLinearFilter;
    tex.magFilter = THREE.LinearFilter;
    tex.needsUpdate = true;
    return tex;
  }

  // ----- ГЕОМЕТРИЯ КАРТЫ: лежит на столе (плоскость XZ) -----
  const CARD_W = 34;           // крупнее
  const CARD_H = 54;           // 5:8 ~ классика
  const cardGeom = new THREE.PlaneGeometry(CARD_W, CARD_H);
  cardGeom.rotateX(-Math.PI / 2); // положили плоскость на «стол» (XZ)

  // Рубашка
  const backTex = new THREE.TextureLoader().load(backUrl, tuneTexture);
  const backMat = new THREE.MeshBasicMaterial({ map: backTex });

  // Динамический список карт на столе
  let cards = [];

  // --- tween позиции (x,z) и поворота по Y (на топ-дауне Y — «вверх») ---
  function tweenXZ(mesh, from, to, ms, done) {
    const t0 = performance.now();
    (function step(now) {
      const p = Math.min(1, (now - t0) / ms);
      mesh.position.x = from.x + (to.x - from.x) * p;
      mesh.position.z = from.z + (to.z - from.z) * p;
      mesh.rotation.y = from.ry + (to.ry - from.ry) * p;
      if (p < 1) requestAnimationFrame(step); else done && done();
    })(t0);
  }

  // подсветка при hover
  const HOVER_Y = 2.2;
  function attachHover(mesh) {
    mesh.userData.baseY = 0;
    mesh.userData.hovered = false;
  }

  // вычисляем масштаб/сдвиг, чтобы расклад влез в окно
  function computeFit(points) {
    if (!points.length) return { cx:0, cz:0, scale:1, pad: 8 };
    let minX=Infinity, maxX=-Infinity, minZ=Infinity, maxZ=-Infinity;
    for (const p of points) {
      if (p.x < minX) minX = p.x;
      if (p.x > maxX) maxX = p.x;
      if (p.z < minZ) minZ = p.z;
      if (p.z > maxZ) maxZ = p.z;
    }
    const cx = (minX + maxX) / 2;
    const cz = (minZ + maxZ) / 2;

    const viewW = camera.right - camera.left;
    const viewH = camera.top   - camera.bottom;

    const pad = 10; // поля
    const needW = (maxX - minX) + CARD_W + pad * 2;
    const needH = (maxZ - minZ) + CARD_H + pad * 2;

    const sx = viewW / needW;
    const sz = viewH / needH;
    const scale = Math.min(sx, sz, 1.0);
    return { cx, cz, scale, pad };
  }

  // Очистка стола
  function clearTable() {
    for (const m of cards) scene.remove(m);
    cards = [];
  }

  // Перемешивание: просто кучка рубашек вверху
  function shuffle() {
    clearTable();
    const N = 12; // визуальная «стопка» (чисто косметика)
    for (let i = 0; i < N; i++) {
      const m = new THREE.Mesh(cardGeom, backMat);
      m.position.set(-60 + Math.random()*2-1, 0, 46 + Math.random()*2-1);
      m.rotation.y = (Math.random()-0.5)*0.1;
      attachHover(m);
      scene.add(m);
      cards.push(m);
    }
  }

  // Вспомогательная загрузка лицевой карты с анти-мылом
  function loadFaceMaterial(url) {
    return new Promise(res => {
      new THREE.TextureLoader().load(url, t => {
        tuneTexture(t);
        res(new THREE.MeshBasicMaterial({ map: t }));
      }, undefined, () => {
        // если урл битый — оставляем рубашку
        res(backMat);
      });
    });
  }

  // ВЫКЛАДКА
  async function deal() {
    try {
      if (!dealUrl) { console.error('[tarot] no dealUrl'); return; }
      const resp = await fetch(dealUrl, { method:'POST', headers:{ 'X-CSRFToken': getCsrf?.() || '' }});
      const data = await resp.json(); // [{x,z,img_url,reversed},...]

      clearTable();

      // fit, чтобы точно влезло в рамку
      const pts = data.map(d => ({ x: d.x, z: d.z }));
      const fit = computeFit(pts);

      for (let i = 0; i < data.length; i++) {
        const info = data[i];

        // меш на стол — начинаем с рубашки
        const m = new THREE.Mesh(cardGeom, backMat);
        m.position.set(-60, 0, 46); // откуда «прилетает»
        m.rotation.set(0, 0, 0);
        attachHover(m);
        scene.add(m);
        cards.push(m);

        const target = {
          x: (info.x - fit.cx) * fit.scale,
          z: (info.z - fit.cz) * fit.scale + 4  // +4 — чуть выше нижней рамки
        };

        // прилёт
        await new Promise(done => {
          tweenXZ(m, { x: m.position.x, z: m.position.z, ry: m.rotation.y }, { x: target.x, z: target.z, ry: 0 }, 420, done);
        });

        // загрузка лицевой
        const faceMat = await loadFaceMaterial(info.img_url);

        // «переворот»: на топ-дауне используем вращение вокруг оси Y
        await new Promise(done => {
          const t0 = performance.now(), dur = 360;
          (function step(now) {
            const p = Math.min(1, (now - t0) / dur);
            // половина — «тонкая» грань, во второй половине меняем материал
            m.rotation.y = Math.PI * p;
            if (p >= 0.5 && m.material !== faceMat) m.material = faceMat;
            if (p < 1) requestAnimationFrame(step); else done();
          })(t0);
        });

        // перевёрнутая? — повернём на 180°, чтобы игрок видел это
        if (info.reversed) {
          m.rotation.y += Math.PI;
        }
      }
    } catch (e) {
      console.error('[tarot] deal error', e);
    }
  }

  // hover-эффект (при наведении приподнимать карту)
  const raycaster = new THREE.Raycaster();
  const mouse = new THREE.Vector2();
  function onMouseMove(ev) {
    const rect = renderer.domElement.getBoundingClientRect();
    mouse.x = ((ev.clientX - rect.left) / rect.width) * 2 - 1;
    mouse.y = -((ev.clientY - rect.top) / rect.height) * 2 + 1;

    raycaster.setFromCamera(mouse, camera);
    const hits = raycaster.intersectObjects(cards, false);
    const hovered = new Set(hits.map(h => h.object));

    for (const m of cards) {
      const need = hovered.has(m);
      if (need && !m.userData.hovered) { m.userData.hovered = true;  m.position.y = HOVER_Y; }
      if (!need && m.userData.hovered) { m.userData.hovered = false; m.position.y = 0; }
    }
  }
  renderer.domElement.addEventListener('mousemove', onMouseMove);

  // Resize
  window.addEventListener('resize', () => {
    const w = mount.clientWidth, h = mount.clientHeight;
    renderer.setSize(w, h);
    aspect = w / h;
    camera.left   = -frustumSize * aspect / 2;
    camera.right  =  frustumSize * aspect / 2;
    camera.top    =  frustumSize / 2;
    camera.bottom = -frustumSize / 2;
    camera.updateProjectionMatrix();
  });

  // Рендер-луп
  (function loop() {
    requestAnimationFrame(loop);
    renderer.render(scene, camera);
  })();

  // Кнопки
  document.getElementById('btn-shuffle')?.addEventListener('click', shuffle);
  document.getElementById('btn-deal')?.addEventListener('click', deal);

  // начальная «кучка» для красоты
  shuffle();
})();
